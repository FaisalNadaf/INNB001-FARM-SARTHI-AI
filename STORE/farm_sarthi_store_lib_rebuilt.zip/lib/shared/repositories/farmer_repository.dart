import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/api_constants.dart';
import '../../core/network/dio_client.dart';
import '../models/farmer_model.dart';

final farmerRepositoryProvider = Provider<FarmerRepository>((ref) {
  return FarmerRepository();
});

class FarmerRepository {
  final Dio _dio = DioClient.instance;

  Future<List<FarmerModel>> fetchFarmers() async {
    try {
      final res = await _dio.get(ApiConstants.farmers);
      final data = res.data;
      List<dynamic> list = const [];

      if (data is List<dynamic>) {
        list = data;
      } else if (data is Map<String, dynamic>) {
        final nested = data['data'];
        if (nested is List<dynamic>) list = nested;
      }

      return list
          .whereType<Map<String, dynamic>>()
          .map(FarmerModel.fromJson)
          .toList();
    } catch (_) {
      return _demoFarmers.map(FarmerModel.fromJson).toList();
    }
  }
}

final List<Map<String, dynamic>> _demoFarmers = [
  {
    "_id": "demo-1",
    "created_at": {"\$date": "2026-03-17T18:50:07.759Z"},
    "location": "Lat: 15.863254, Lng: 74.517476",
    "name": "asdf",
    "phone": "1425367895",
    "requests": [
      {
        "timestamp": {"\$date": "2026-03-17T18:50:07.759Z"},
        "prediction": "Bacterial_leaf_blight",
        "confidence_percent": 59.65,
        "severity": {"score": 100, "level": "critical", "urgency": "immediate"},
        "weather_risk": {"score": 32, "level": "low"},
        "visual_analysis": {
          "leaf_health_visuals": {"estimated_lesion_percent": 51.29}
        },
        "weather": {"location_name": "Belgaum"},
        "request_location": {
          "coordinates": {"lat": 15.863254, "lon": 74.517476}
        },
        "diagnostic_summary": {
          "diagnosis_status": "disease_detected",
          "disease_name": "Bacterial_leaf_blight",
          "disease_type": "bacterial",
          "confidence_percent": 59.65,
          "confidence_band": "medium",
          "severity_score": 100,
          "severity_level": "critical",
          "weather_risk_score": 32,
          "weather_risk_level": "low",
          "estimated_lesion_percent": 51.29,
          "treatment_urgency": "immediate"
        }
      }
    ],
    "total_requests": 1,
    "updated_at": {"\$date": "2026-03-17T18:50:07.759Z"}
  },
  {
    "_id": "demo-2",
    "created_at": {"\$date": "2026-03-17T18:49:06.253Z"},
    "location": "Lat: 15.863254, Lng: 74.517476",
    "name": "faisal1",
    "phone": "1234567890",
    "requests": [
      {
        "timestamp": {"\$date": "2026-03-17T18:49:06.253Z"},
        "prediction": "Tungro",
        "confidence_percent": 97.07,
        "severity": {"score": 100, "level": "critical", "urgency": "immediate"},
        "weather_risk": {"score": 22, "level": "low"},
        "visual_analysis": {
          "leaf_health_visuals": {"estimated_lesion_percent": 36.14}
        },
        "weather": {"location_name": "Belgaum"},
        "request_location": {
          "coordinates": {"lat": 15.863254, "lon": 74.517476}
        },
        "diagnostic_summary": {
          "diagnosis_status": "disease_detected",
          "disease_name": "Tungro",
          "disease_type": "viral",
          "confidence_percent": 97.07,
          "confidence_band": "very_high",
          "severity_score": 100,
          "severity_level": "critical",
          "weather_risk_score": 22,
          "weather_risk_level": "low",
          "estimated_lesion_percent": 36.14,
          "treatment_urgency": "immediate"
        }
      }
    ],
    "total_requests": 1,
    "updated_at": {"\$date": "2026-03-17T18:49:06.253Z"}
  }
];
