class ApiConstants {
  static const String baseUrl = 'http://10.0.2.2:8000';
  static const String farmers = '/farmers';
  static const Duration connectTimeout = Duration(seconds: 20);
  static const Duration receiveTimeout = Duration(seconds: 20);
}
